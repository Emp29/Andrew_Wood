
/**
 * Write a description of class Course here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Course
{
    // instance variables - replace the example below with your own
    // Create courseName.
    private String courseName;
    // Create courseNumber.
    private String courseNumber;

    /**
     * Constructor for objects of class Course
     */
    public Course(String courseName, String courseNumber)
    {
        this.courseName = courseName;
        this.courseNumber = courseNumber;
    }

    public void print()
    {
        System.out.println("course " + courseName + " ID " + courseNumber); 
    }
}
