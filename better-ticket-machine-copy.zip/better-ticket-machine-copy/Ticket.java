import java.util.Date;
/**
 * Write a description of class Ticket here.
 *
 * @author (Andrew J Wood)
 * @version (1.0)
 */
public class Ticket
{
    //Price of ticket in pence
    private int price;
    //Destination
    private String destination;
    //Date of travel
    private Date currentDate=new Date();

    /**
     * Constructor for objects of class Ticket
     */
    public Ticket(String destination, int price)
    {
        // initialise instance variables
        this.destination = destination;
        this.price = price;
    }

    /**
     * Returning the price of a ticket in pence
     */
    public int findPrice()
    {
        return price;
    }
    
    public String findDestination()
    {
        return destination;
    }
    
    public Date findCurrentDate()
    {
        return currentDate;
    }
}
